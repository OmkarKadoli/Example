const express = require('express');
const bodyParser = require('body-parser');
const request = require('request');
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));
const { stringify } = require('querystring');

const app = express();

app.use(express.json());

app.get('/', (_, res) => res.sendFile(__dirname + '/index.html'));

app.post('/defcaptcha', async (req,res) => {
    if (!req.body.captcha)
    return res.json({ success: false, msg: 'Please select captcha' });

    //Secret Key of Captcha

    const secretKey = '6LedHWIeAAAAAHzzDFl39ZPyOsofqalZPDNsx-79';

    
    // Verify URL

    const query = stringify({
        secret: secretKey,
        response: req.body.captcha,
        remoteip: req.connection.remoteAddress
      });

      const verifyURL = `https://google.com/recaptcha/api/siteverify?${query}`;

     
    //Make Request to verifyURL

    const body = await fetch(verifyURL).then(res => res.json());
   
      
  if (body.success !== undefined && !body.success)
  {
      // If not successful
    return res.json({ success: false, msg: 'Failed captcha verification' });
  }
  else{

    // If successful
    return res.json({ success: true, msg: 'Captcha passed' });
  }
  
});

app.listen(3030, () => {
    console.log("Server Start on port 3030");
})